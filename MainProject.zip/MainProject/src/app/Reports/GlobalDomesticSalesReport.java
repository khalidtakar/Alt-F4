package app.Reports;

public class GlobalDomesticSalesReport {
}
