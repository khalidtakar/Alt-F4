package app.Reports;

public class IndividualDomesticSalesReport {
}
